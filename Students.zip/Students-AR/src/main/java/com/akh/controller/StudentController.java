package com.akh.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akh.entity.StudentEntity;
import com.akh.service.StudentService;
import com.akh.vo.StudentAndStudentMarksVO;

@RestController
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@GetMapping("/byid/{studentId}")
	public Optional<StudentEntity> getStudentById(@PathVariable Integer studentId) {
		return studentService.getStudentById(studentId);
		
	}
	
	@PostMapping("/addstudent")
	public void addStudent(@RequestBody StudentEntity student) {
		studentService.saveStudent(student);
	}
	
	@GetMapping("/bylname/{name}")
	public Optional<StudentEntity> getStudentByLName(@PathVariable String name){
		return studentService.getStudentByLname(name);
	}
	
	@GetMapping("/studentwithmark/{id}")
	public StudentAndStudentMarksVO getStudentAndMark(@PathVariable Integer id){
		return studentService.getStudentAndMarkById(id);
	}

}
