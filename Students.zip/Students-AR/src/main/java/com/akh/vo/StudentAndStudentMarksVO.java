package com.akh.vo;

import com.akh.entity.StudentEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentAndStudentMarksVO {
	
	private StudentEntity studentDetails;
	private StudentMarksVO StudentMarks;

}
