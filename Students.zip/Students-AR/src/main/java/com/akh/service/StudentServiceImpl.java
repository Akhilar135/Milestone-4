package com.akh.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akh.entity.StudentEntity;
import com.akh.repository.StudentRepository;
import com.akh.vo.StudentAndStudentMarksVO;
import com.akh.vo.StudentMarksVO;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private StudentMarksClient marksClient;

	@Override
	public Optional<StudentEntity> getStudentById(Integer studentId) {
		
		return studentRepository.findById(studentId);
	}

	@Override
	public Optional<StudentEntity> getStudentByLname(String name) {
		
		return studentRepository.findBylName(name);
	}

	@Override
	public StudentAndStudentMarksVO getStudentAndMarkById(Integer studentId) {
		Optional<StudentEntity> optional =studentRepository.findById(studentId);
		if(optional.isPresent()) {
			StudentEntity studentEntity = optional.get();
			Integer marksId = studentEntity.getId();
			StudentMarksVO marksVO = marksClient.getStudentWithMarks(marksId);
			StudentAndStudentMarksVO smVO= new StudentAndStudentMarksVO();
			smVO.setStudentDetails(studentEntity);
			smVO.setStudentMarks(marksVO);
			return smVO;
		}
		
		return null;
	}

	@Override
	public void saveStudent(StudentEntity student) {
		studentRepository.save(student);
		
	}
	
	

}
