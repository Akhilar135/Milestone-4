package com.akh.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.akh.entity.StudentEntity;
import com.akh.vo.StudentAndStudentMarksVO;

@Service
public interface StudentService {
	
	public Optional<StudentEntity> getStudentById(Integer studentId);
	public Optional<StudentEntity> getStudentByLname(String name);
	public StudentAndStudentMarksVO getStudentAndMarkById(Integer studentId);
	public void saveStudent(StudentEntity student);

}
