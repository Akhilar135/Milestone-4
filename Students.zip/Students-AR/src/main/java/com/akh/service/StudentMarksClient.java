package com.akh.service;



import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.akh.vo.StudentMarksVO;

@FeignClient(name="STUDENTMARKS-AR")
public interface StudentMarksClient {
	
	@GetMapping("/marks/byid/{id}")
	public StudentMarksVO getStudentWithMarks(@PathVariable Integer id);
	
	

}
