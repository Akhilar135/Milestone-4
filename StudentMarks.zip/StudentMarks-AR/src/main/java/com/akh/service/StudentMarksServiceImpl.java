package com.akh.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akh.entity.StudentMarksEntity;
import com.akh.repository.StudentMarksRepository;

@Service
public class StudentMarksServiceImpl implements StudentMarksService{

	@Autowired
	private StudentMarksRepository marksRepository;
	
	@Override
	public Optional<StudentMarksEntity> getMarksById(Integer id) {
		return marksRepository.findById(id);
	}

	@Override
	public void addStudentMark(StudentMarksEntity marks) {
		marksRepository.save(marks);
		
	}
	
	

}
