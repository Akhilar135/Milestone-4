package com.akh.service;

import java.util.Optional;

import com.akh.entity.StudentMarksEntity;

public interface StudentMarksService {
	
	public Optional<StudentMarksEntity> getMarksById(Integer id);
	public void addStudentMark(StudentMarksEntity marks);

}
