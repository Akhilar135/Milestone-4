package com.akh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentMarksArApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentMarksArApplication.class, args);
	}

}
