package com.akh.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akh.entity.StudentMarksEntity;
import com.akh.service.StudentMarksServiceImpl;

@RestController
@RequestMapping("/marks")
public class StudentMarksController {
	
	@Autowired
	private StudentMarksServiceImpl serviceImpl;
	
	@GetMapping("/byid/{id}")
	public Optional<StudentMarksEntity> getStudentMarksById(@PathVariable Integer id){
		return serviceImpl.getMarksById(id);
	}	
	
	@PostMapping("/addMarks")
	public void addMarks(@RequestBody StudentMarksEntity marks) {
		serviceImpl.addStudentMark(marks);
	}
}
	


