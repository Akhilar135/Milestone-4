package com.akh.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.akh.entity.StudentMarksEntity;

public interface StudentMarksRepository extends JpaRepository<StudentMarksEntity, Integer>{

}
